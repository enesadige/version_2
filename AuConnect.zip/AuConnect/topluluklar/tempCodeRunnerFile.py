        return "/img/" + self.image
